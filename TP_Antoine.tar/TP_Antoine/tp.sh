#!/bin/bash

PATH=/usr/bin:/bin

API_URL="http://localhost:5000"
OUTPUT="/home/vegeta/scripts_bash/TP_Antoine/sales.txt"

CARDS=("rtx3060" "rtx3070" "rtx3080" "rtx3090")

> "$OUTPUT"

for card in "${CARDS[@]}"
do
    sales=$(curl -s "$API_URL/$card")
    echo "$card : $sales" >> "$OUTPUT"
done

echo "Execution : $(date)" >> /home/vegeta/scripts_bash/TP_Antoine/debug.log