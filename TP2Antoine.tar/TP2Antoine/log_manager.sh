#!/bin/bash

REPORT="report_logs.txt"
LOGFILES=$(ls access*.log 2>/dev/null)

DATE=$(date)

TOTAL_REQ=0
TOTAL_ERR=0

> $REPORT

echo "===== RAPPORT D'ANALYSE LOGS =====" >> $REPORT
echo "Date : $DATE" >> $REPORT
echo "" >> $REPORT

for file in $LOGFILES
do
    REQ=$(wc -l < $file)
    ERR=$(grep -E " 401 | 403 " $file | wc -l)

    TOTAL_REQ=$((TOTAL_REQ + REQ))
    TOTAL_ERR=$((TOTAL_ERR + ERR))
done

echo "Total requêtes : $TOTAL_REQ" >> $REPORT
echo "Total erreurs : $TOTAL_ERR" >> $REPORT
echo "" >> $REPORT

echo "Top 5 IP :" >> $REPORT
cat access*.log | cut -d' ' -f1 | sort | uniq -c | sort -nr | head -5 >> $REPORT

echo "" >> $REPORT
echo "IP suspectes (>5 erreurs 401) :" >> $REPORT
grep " 401 " access*.log | cut -d' ' -f1 | sort | uniq -c | awk '$1>5 {print "IP: "$2" - Tentatives: "$1}' >> $REPORT

echo "" >> $REPORT
echo "Compression des anciens logs..." >> $REPORT
gzip access_*.log 2>/dev/null

echo "Rapport généré dans $REPORT"