#!/bin/bash

LOGFILE="access.log"
OUTPUT="suspicious_ips.txt"

> $OUTPUT

grep " 401 " $LOGFILE | cut -d' ' -f1 | sort | uniq -c | while read count ip
do
    if [ $count -gt 5 ]
    then
        echo "IP: $ip - Tentatives: $count" >> $OUTPUT
    fi
done

echo "Analyse terminée. Résultat dans $OUTPUT"