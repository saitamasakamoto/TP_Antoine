#!/bin/bash

LOGFILE="access.log"

while true
do
    echo "------ MENU ANALYSE LOGS ------"
    echo "1) Nombre total de requêtes"
    echo "2) Nombre d'erreurs (401, 403)"
    echo "3) Top 5 IP"
    echo "4) Pages les plus consultées"
    echo "5) Quitter"
    read -p "Choix : " choix

    case $choix in
        1)
            wc -l $LOGFILE
            ;;
        2)
            grep -E " 401 | 403 " $LOGFILE | wc -l
            ;;
        3)
            cut -d' ' -f1 $LOGFILE | sort | uniq -c | sort -nr | head -5
            ;;
        4)
            cut -d' ' -f7 $LOGFILE | sort | uniq -c | sort -nr | head -5
            ;;
        5)
            exit 0
            ;;
        *)
            echo "Choix invalide"
            ;;
    esac
done
