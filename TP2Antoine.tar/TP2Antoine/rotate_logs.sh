#!/bin/bash

LOGFILE="access.log"
MAXSIZE=1048576   # 1MB en octets

FILESIZE=$(stat -c%s "$LOGFILE")

if [ $FILESIZE -gt $MAXSIZE ]
then
    DATE=$(date +%Y%m%d)
    NEWNAME="access_$DATE.log"

    mv $LOGFILE $NEWNAME
    touch $LOGFILE

    echo "Rotation effectuée : $NEWNAME créé"
else
    echo "Taille OK : pas de rotation"
fi